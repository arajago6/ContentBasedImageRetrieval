.. _contents:

PyWavelets
==========

.. toctree::
   :maxdepth: 2

   ref/index
   regression/index
   dev/index
   resources

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
