#!/usr/bin/env python

# tests moved to test_doc.py
